To run the sac_free.jl, you first need to generate a t.in file using make_tin.jl. This reads in a complete list of G(tau) bins, generated from QMC. The two input files for make_tin.jl are cor.dat and tgrid.dat.

cor.dat contains the G(tau) bins. The value of G(tau_i) for each bin is listed (one value per row), and each bin is seperated by "1," which is just usd a an indicator to seperate the bins. This will look like:

1
G_1(0)
G_1(tau_1)
...
G_1(tau_N-1)
G_1(beta)
1
G_2(0)
G_2(tau_1)
...
G_2(tau_N-1)
G_2(beta)
1
...

For proper normalization of the Fermionic spectral function, your G(tau) data must include both G(0) and G(beta).


tgrid.dat contains the tau grid that G(tau) is evaluated on. For the file, each value of tau_i is listed, one value per row. This will look like:

0
tau_1
...
tau_N-1
beta